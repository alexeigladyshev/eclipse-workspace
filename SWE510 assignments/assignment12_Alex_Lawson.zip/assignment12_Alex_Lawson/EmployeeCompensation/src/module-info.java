
module EmployeeCompensation {
	exports employeeclasses;
}