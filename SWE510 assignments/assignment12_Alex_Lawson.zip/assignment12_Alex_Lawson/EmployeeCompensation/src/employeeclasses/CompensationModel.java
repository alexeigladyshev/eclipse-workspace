package employeeclasses;
//this is the abstract class that will be extended by all of the different types of employee compensations

public abstract class CompensationModel {

	public abstract double earnings();
}
