This program is from assignment 6, that I modified for this assignment.

To run the program, in the command prompt go into the folder where the "myruntime" directory is located. The command needed to execute the program is:


myruntime/bin/java -m EmployeeCompTestClass/testproject.CompensationTest


Output should look like this:

Employee starts as CommissionCompensationModel
Employee name: Cassidy Smith
Social security number: xxx-xx-xxxx
earnings: $1500.00

Changed employee to BasePlusCommissionCompensationModel
Employee name: Cassidy Smith
Social security number: xxx-xx-xxxx
earnings: $2125.00

Changed employee to SalariedCompensationModel
Employee name: Cassidy Smith
Social security number: xxx-xx-xxxx
earnings: $1250.00

Changed employee to HourlyCompensationModel
Employee name: Cassidy Smith
Social security number: xxx-xx-xxxx
earnings: $1925.00