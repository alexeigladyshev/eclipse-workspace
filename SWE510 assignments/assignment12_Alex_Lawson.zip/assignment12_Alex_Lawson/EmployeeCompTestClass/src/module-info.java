
module EmployeeCompTestClass {

	requires EmployeeCompensation;
}