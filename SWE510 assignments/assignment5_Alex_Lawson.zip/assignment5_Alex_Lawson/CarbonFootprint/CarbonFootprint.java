
public interface CarbonFootprint {

	public abstract void getCarbonFootprint();

}
