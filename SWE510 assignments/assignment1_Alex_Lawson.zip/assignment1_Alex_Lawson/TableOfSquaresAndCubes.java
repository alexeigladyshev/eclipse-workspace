
public class TableOfSquaresAndCubes {

	public static void main(String[] args) {
		
		System.out.printf("%s\t\t%s\t\t%s\n","number","square","cube" );
		
		for (int i=0; i<=10;i++) {
			
			
			System.out.format("%d\t\t%d\t\t%d%n",i, i*i, i*i*i);
		}

	}

}
